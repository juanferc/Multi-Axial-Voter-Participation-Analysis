$(document).ready( function () {
    $('#sampleTable').DataTable();
} );

$( "#tabs" ).tabs();
